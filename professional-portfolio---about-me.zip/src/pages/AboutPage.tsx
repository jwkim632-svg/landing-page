import { motion } from 'motion/react';
import { Card } from '../components/Card';
import { Button } from '../components/Button';
import { ArrowLeft, CheckCircle2 } from 'lucide-react';

export const AboutPage = () => {
  const skills = ['React', 'TypeScript', 'Product Management', 'Data Analysis', 'UI/UX Design', 'Agile'];
  const strengths = [
    { title: '사용자 중심 사고', desc: '사용자의 목소리에서 기회를 발견하고 해결책을 제시합니다.' },
    { title: '데이터 기반 결정', desc: '직관이 아닌 데이터로 성과를 증명하고 방향을 설정합니다.' },
    { title: '유연한 커뮤니케이션', desc: '다양한 이해관계자와의 원활한 협업을 이끌어냅니다.' },
  ];

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 py-12">
      <Card className="max-w-2xl">
        <div className="flex items-center gap-4 mb-8">
          <Button to="/" variant="ghost" className="w-auto p-2 rounded-full">
            <ArrowLeft className="w-6 h-6" />
          </Button>
          <h1 className="text-2xl font-bold">상세 소개</h1>
        </div>

        <div className="space-y-8">
          <section>
            <h2 className="text-lg font-bold text-primary mb-3">자기소개</h2>
            <p className="text-gray-600 leading-relaxed">
              저는 단순히 기능을 만드는 사람이 아니라, 비즈니스 문제를 해결하는 사람입니다. 
              지난 5년간 다양한 프로젝트를 수행하며 사용자의 불편함을 기술로 해결하는 과정에서 큰 보람을 느껴왔습니다. 
              항상 '왜'라는 질문을 던지며 본질에 집중합니다.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-primary mb-3">핵심 강점</h2>
            <div className="grid gap-4">
              {strengths.map((s, i) => (
                <div key={i} className="flex gap-3 p-4 bg-gray-50 rounded-2xl border border-gray-100">
                  <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />
                  <div>
                    <h3 className="font-bold text-gray-900">{s.title}</h3>
                    <p className="text-sm text-gray-500">{s.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </section>

          <section>
            <h2 className="text-lg font-bold text-primary mb-3">보유 기술</h2>
            <div className="flex flex-wrap gap-2">
              {skills.map(skill => (
                <span key={skill} className="px-3 py-1 bg-blue-50 text-blue-600 text-sm font-medium rounded-full border border-blue-100">
                  {skill}
                </span>
              ))}
            </div>
          </section>
        </div>

        <div className="mt-10">
          <Button to="/journey" variant="primary">
            나의 여정 확인하기
          </Button>
        </div>
      </Card>
    </div>
  );
};
