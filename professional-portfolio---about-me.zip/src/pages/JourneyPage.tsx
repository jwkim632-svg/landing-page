import { motion } from 'motion/react';
import { Card } from '../components/Card';
import { Button } from '../components/Button';
import { ArrowLeft, Calendar, MapPin } from 'lucide-react';

export const JourneyPage = () => {
  const events = [
    {
      date: '2023 - Present',
      title: 'Senior Product Manager',
      company: 'Tech Innovators Co.',
      desc: '신규 모바일 서비스 런칭 및 MAU 200% 성장 달성. 데이터 기반 기능 개선 주도.',
      location: 'Seoul, Korea'
    },
    {
      date: '2020 - 2023',
      title: 'Product Designer',
      company: 'Creative Studio',
      desc: '사용자 경험 중심의 웹/앱 디자인 시스템 구축. 20여개 클라이언트 프로젝트 성공적 수행.',
      location: 'Pangyo, Korea'
    },
    {
      date: '2016 - 2020',
      title: 'Computer Science & Design',
      company: 'Hankuk University',
      desc: '공학적 사고와 디자인 감각을 동시에 함양. 졸업 프로젝트 최우수상 수상.',
      location: 'Seoul, Korea'
    }
  ];

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 py-12">
      <Card className="max-w-2xl">
        <div className="flex items-center gap-4 mb-8">
          <Button to="/" variant="ghost" className="w-auto p-2 rounded-full">
            <ArrowLeft className="w-6 h-6" />
          </Button>
          <h1 className="text-2xl font-bold">나의 여정</h1>
        </div>

        <div className="relative space-y-8 before:absolute before:inset-0 before:ml-5 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-transparent before:via-gray-200 before:to-transparent">
          {events.map((event, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, x: i % 2 === 0 ? -20 : 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active"
            >
              {/* Dot */}
              <div className="flex items-center justify-center w-10 h-10 rounded-full border border-white bg-white shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2">
                <div className="w-3 h-3 rounded-full bg-primary" />
              </div>

              {/* Content */}
              <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-4 rounded-2xl bg-gray-50 border border-gray-100 shadow-sm">
                <div className="flex items-center justify-between mb-1">
                  <time className="text-xs font-bold text-primary flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    {event.date}
                  </time>
                </div>
                <div className="text-lg font-bold text-gray-900">{event.title}</div>
                <div className="text-sm font-semibold text-gray-600 mb-2">{event.company}</div>
                <p className="text-sm text-gray-500 leading-relaxed">{event.desc}</p>
                <div className="mt-2 text-xs text-gray-400 flex items-center gap-1">
                  <MapPin className="w-3 h-3" />
                  {event.location}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-12">
          <Button to="/gallery" variant="primary">
            일상 갤러리 보기
          </Button>
        </div>
      </Card>
    </div>
  );
};
