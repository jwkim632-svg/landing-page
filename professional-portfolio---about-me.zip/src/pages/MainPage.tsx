import { motion } from 'motion/react';
import { Card } from '../components/Card';
import { Button } from '../components/Button';
import { User, Briefcase, Camera, Mail, ArrowRight, ExternalLink } from 'lucide-react';

export const MainPage = () => {
  const links = [
    { id: 'sub1', title: '상세 소개 (About)', path: '/about', icon: <User />, color: 'bg-blue-50 text-blue-600' },
    { id: 'sub2', title: '타임라인 (Journey)', path: '/journey', icon: <Briefcase />, color: 'bg-emerald-50 text-emerald-600' },
    { id: 'sub3', title: '갤러리 (Life)', path: '/gallery', icon: <Camera />, color: 'bg-purple-50 text-purple-600' },
    { id: 'sub4', title: '연락처 (Contact)', path: '/contact', icon: <Mail />, color: 'bg-orange-50 text-orange-600' },
  ];

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4">
      <Card className="relative overflow-hidden">
        {/* Background Accent */}
        <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-r from-blue-500 to-emerald-500 -z-10" />
        
        <div className="flex flex-col items-center pt-8">
          <motion.div 
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="relative"
          >
            <img 
              src="https://loremflickr.com/400/400/portrait?random=1" 
              alt="Profile" 
              className="w-32 h-32 rounded-full border-4 border-white object-cover shadow-xl"
              referrerPolicy="no-referrer"
            />
            <div className="absolute bottom-1 right-1 w-6 h-6 bg-emerald-500 border-4 border-white rounded-full" />
          </motion.div>

          <div className="text-center mt-6 space-y-2">
            <h1 className="text-2xl font-bold text-gray-900">
              안녕하세요, 비즈니스 성장을 이끄는<br />
              <span className="text-primary">기획자 김철수</span>입니다.
            </h1>
            <p className="text-gray-500 text-sm px-4">
              사용자 중심의 문제 해결과 데이터 기반 의사결정을 통해 가치를 창출합니다.
            </p>
          </div>

          <div className="w-full mt-8 space-y-3">
            {links.map((link, index) => (
              <motion.div
                key={link.id}
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.2 + index * 0.1 }}
              >
                <Button 
                  to={link.path} 
                  variant="ghost" 
                  className="justify-between bg-white/50 hover:bg-white border border-gray-100 group"
                >
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-xl ${link.color}`}>
                      {link.icon}
                    </div>
                    <span className="font-semibold">{link.title}</span>
                  </div>
                  <ArrowRight className="w-4 h-4 text-gray-400 group-hover:text-primary transition-colors" />
                </Button>
              </motion.div>
            ))}
          </div>

          <div className="w-full mt-8 pt-6 border-t border-gray-100">
            <Button variant="primary" icon={<ExternalLink className="w-4 h-4" />}>
              커피챗 제안하기
            </Button>
          </div>
        </div>
      </Card>
      
      <footer className="mt-8 text-gray-400 text-xs text-center">
        © 2026 Chulsoo Kim. All rights reserved.
      </footer>
    </div>
  );
};
