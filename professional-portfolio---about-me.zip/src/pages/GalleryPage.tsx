import { motion } from 'motion/react';
import { Card } from '../components/Card';
import { Button } from '../components/Button';
import { ArrowLeft } from 'lucide-react';

export const GalleryPage = () => {
  const images = [
    { url: 'https://loremflickr.com/800/600/workspace?random=1', caption: '집중하기 좋은 나만의 워크스페이스' },
    { url: 'https://loremflickr.com/800/1000/meeting?random=2', caption: '팀원들과의 즐거운 아이디어 회의' },
    { url: 'https://loremflickr.com/800/600/technology?random=3', caption: '새로운 기술 스택 탐구 중' },
    { url: 'https://loremflickr.com/800/800/coffee?random=4', caption: '오후의 활력을 불어넣는 커피 한 잔' },
    { url: 'https://loremflickr.com/800/1200/city?random=5', caption: '영감을 얻기 위한 주말 산책' },
    { url: 'https://loremflickr.com/800/600/design?random=6', caption: '디자인 시스템 가이드라인 작업' },
  ];

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 py-12">
      <Card className="max-w-4xl">
        <div className="flex items-center gap-4 mb-8">
          <Button to="/" variant="ghost" className="w-auto p-2 rounded-full">
            <ArrowLeft className="w-6 h-6" />
          </Button>
          <h1 className="text-2xl font-bold">라이프 갤러리</h1>
        </div>

        <div className="columns-1 sm:columns-2 gap-4 space-y-4">
          {images.map((img, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="relative group rounded-2xl overflow-hidden cursor-pointer"
            >
              <img 
                src={img.url} 
                alt={img.caption} 
                className="w-full h-auto object-cover transition-transform duration-500 group-hover:scale-110"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
                <p className="text-white text-sm font-medium">{img.caption}</p>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-10">
          <Button to="/contact" variant="primary">
            연락처 확인하기
          </Button>
        </div>
      </Card>
    </div>
  );
};
