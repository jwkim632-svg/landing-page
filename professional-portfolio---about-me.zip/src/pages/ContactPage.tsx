import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Card } from '../components/Card';
import { Button } from '../components/Button';
import { ArrowLeft, Send, Github, Linkedin, Mail, Phone } from 'lucide-react';

export const ContactPage = () => {
  const [formState, setFormState] = useState({ name: '', email: '', message: '' });
  const [isSent, setIsSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate sending
    setTimeout(() => {
      setIsSent(true);
      setFormState({ name: '', email: '', message: '' });
    }, 1000);
  };

  const socialLinks = [
    { icon: <Github />, label: 'GitHub', url: 'https://github.com' },
    { icon: <Linkedin />, label: 'LinkedIn', url: 'https://linkedin.com' },
    { icon: <Mail />, label: 'Email', url: 'mailto:jwkim632@gmail.com' },
    { icon: <Phone />, label: 'Call', url: 'tel:010-1234-5678' },
  ];

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 py-12">
      <Card className="max-w-xl">
        <div className="flex items-center gap-4 mb-8">
          <Button to="/" variant="ghost" className="w-auto p-2 rounded-full">
            <ArrowLeft className="w-6 h-6" />
          </Button>
          <h1 className="text-2xl font-bold">연락처</h1>
        </div>

        <div className="space-y-8">
          <div className="grid grid-cols-2 gap-4">
            {socialLinks.map((link, i) => (
              <a 
                key={i}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 p-4 bg-gray-50 rounded-2xl border border-gray-100 hover:bg-white hover:border-primary/30 transition-all group"
              >
                <div className="p-2 bg-white rounded-xl text-gray-400 group-hover:text-primary transition-colors">
                  {link.icon}
                </div>
                <span className="font-semibold text-gray-700">{link.label}</span>
              </a>
            ))}
          </div>

          <div className="pt-6 border-t border-gray-100">
            <h2 className="text-lg font-bold mb-4">메시지 보내기</h2>
            {isSent ? (
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="p-6 bg-emerald-50 text-emerald-700 rounded-2xl text-center border border-emerald-100"
              >
                <p className="font-bold">메시지가 성공적으로 전송되었습니다!</p>
                <p className="text-sm mt-1">빠른 시일 내에 답변 드리겠습니다.</p>
                <button 
                  onClick={() => setIsSent(false)}
                  className="mt-4 text-sm underline font-medium"
                >
                  새 메시지 작성
                </button>
              </motion.div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-500 uppercase ml-1">성함</label>
                  <input 
                    type="text" 
                    required
                    value={formState.name}
                    onChange={e => setFormState({...formState, name: e.target.value})}
                    className="w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-100 focus:border-primary focus:bg-white outline-none transition-all"
                    placeholder="홍길동"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-500 uppercase ml-1">이메일</label>
                  <input 
                    type="email" 
                    required
                    value={formState.email}
                    onChange={e => setFormState({...formState, email: e.target.value})}
                    className="w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-100 focus:border-primary focus:bg-white outline-none transition-all"
                    placeholder="example@email.com"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-500 uppercase ml-1">내용</label>
                  <textarea 
                    required
                    rows={4}
                    value={formState.message}
                    onChange={e => setFormState({...formState, message: e.target.value})}
                    className="w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-100 focus:border-primary focus:bg-white outline-none transition-all resize-none"
                    placeholder="제안하고 싶은 내용을 입력해주세요."
                  />
                </div>
                <Button variant="primary" icon={<Send className="w-4 h-4" />}>
                  전송하기
                </Button>
              </form>
            )}
          </div>
        </div>
      </Card>
    </div>
  );
};
