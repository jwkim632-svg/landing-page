import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';

interface ButtonProps {
  children: React.ReactNode;
  to?: string;
  onClick?: () => void;
  className?: string;
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost';
  icon?: React.ReactNode;
}

export const Button = ({ children, to, onClick, className, variant = 'primary', icon }: ButtonProps) => {
  const baseStyles = "flex items-center justify-center gap-2 px-6 py-3 rounded-2xl font-medium transition-all active:scale-95 w-full";
  
  const variants = {
    primary: "bg-primary text-white hover:bg-blue-700 shadow-lg shadow-blue-500/30",
    secondary: "bg-secondary text-white hover:bg-emerald-600 shadow-lg shadow-emerald-500/30",
    outline: "border-2 border-primary text-primary hover:bg-primary/5",
    ghost: "text-gray-600 hover:bg-gray-100",
  };

  const content = (
    <>
      {icon && <span className="w-5 h-5">{icon}</span>}
      {children}
    </>
  );

  if (to) {
    return (
      <Link to={to} className={cn(baseStyles, variants[variant], className)}>
        {content}
      </Link>
    );
  }

  return (
    <button onClick={onClick} className={cn(baseStyles, variants[variant], className)}>
      {content}
    </button>
  );
};
